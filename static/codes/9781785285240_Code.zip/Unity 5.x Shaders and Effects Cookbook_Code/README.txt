This is the complete code bundle provided by the author, as making individual chapter wise packages would be quite inefficient because there are many shared assets that would be replicated and potentially cause the project to be quite messy.

Chapter 7 - The code files are in the First edition folder (First edition | 5084_07_Code)

Chapter 8 - The code files are in the First edition folder (First edition | 5084_08_Code)